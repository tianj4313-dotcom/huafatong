# 华法通 Pro 12.0

这是基于上传的华法通 Pro 10.x 单页网页源码继续升级的离线优先版本，尽量保留原有本地检索、录入、TXT/MD/JSON 导入、JSON 备份和官方入口，并新增类别/效力/来源筛选、来源/机关/文号字段、CSV 导入导出、重复资料跳过、收藏、复习卡、基础测验、云端公开只读连接配置与 Android Capacitor 工程脚手架。

## 本版新增：官方核验登记与修订版本追踪
- 新增“核验与修订”页，可登记法规名称、官方来源 URL、发布机关、核验日期、核验结论及备注。记录是人工登记，不会自动判断法律效力。
- 支持同一法规保存多个正文版本、填写版本日期、版本标签、修订说明和官方依据链接。
- 提供按换行位置展示两版文本差异的简易对比；它不是法律语义差异分析，换行变化也会被显示为差异。
- 新增本地版本记录存储。该数据保存在当前浏览器 localStorage，需定期导出/另行备份；目前通用 JSON 导出仍主要导出资料和学习记录，不会自动把核验/修订记录打包。

## 一、网页部署
1. 将本目录中的 `index.html`、`manifest.json`、`sw.js` 放到同一目录。
2. 部署到支持 HTTPS 的静态托管（如 Netlify、Cloudflare Pages、GitHub Pages 或自有 HTTPS 网站）。不要直接用 `file://` 打开测试 PWA；建议用本地 HTTP 服务。
3. 访问网站并在浏览器菜单中选择“安装应用/添加到主屏幕”。
4. 更新后若仍显示旧版，关闭应用并清理该站点缓存/存储，或确认 service worker 已更新。

## 二、Supabase 云端数据库（可选）
1. 创建 Supabase 项目。
2. 打开 SQL Editor，执行 `supabase/schema.sql`。
3. 通过受控管理界面、SQL Editor 或可信后端导入经过核验的法规数据。字段：`title, category, body, status, issuer, number, source_url, date, verification_status, verified_at, version_label, official_basis, content_sha256, is_published`。SQL 还建立 `law_revisions` 与 `law_verifications` 两张关联表。
4. 在应用“数据与设置”页填写 Project URL 和 publishable/anon key，点击“连接并测试”。前端仅请求 `public.laws` 的公开只读记录。
5. 导入后默认 `is_published=false`，需要在可信管理流程完成核验后才可发布；前端当前读取 `laws` 表基础字段，尚未把云端修订表和核验表接入版本页。表字段、RLS 策略或权限调整后需重新测试。切勿将 `service_role` / 管理员密钥放入前端、仓库或 APK。

注意：示例 schema 开放公开 SELECT，因此只应存放允许公开发布的法规资料，不要把个人信息、付费内容或内部文件放入此表。公开 anon key 不是秘密；安全性依赖 RLS 和权限配置。

## 三、官方数据与自有导入
- 官方核验入口已内置：国家法律法规数据库 https://flk.npc.gov.cn/ ，国家行政法规库 https://xzfg.moj.gov.cn/ ，最高人民法院 https://www.court.gov.cn/ ，最高人民检察院 https://www.spp.gov.cn/ ，中国政府网政策文件 https://www.gov.cn/zhengce/ 。
- 当前版本不会自动爬取或声称同步这些站点。应遵守网站条款、版权/数据使用规则与访问限制，优先使用官方公开下载、开放接口或依法取得的数据。
- TXT/MD：作为一份资料导入。JSON：支持本应用导出的 `{documents:[...]}` 或资料数组。CSV：支持 `title,type,body,date,status,issuer,number,url` 列；文本字段含逗号时需使用标准 CSV 双引号转义。
- “现行有效（已核验）”是人工标注，不是应用自动判断。数据库已预留核验日期、官方依据、内容摘要哈希和版本记录字段；仍需建立人工审核流程与定期复核机制。

## 四、Android 构建
需要 Node.js 20+、npm、Android Studio 与 Android SDK。当前包包含 Capacitor 配置，但未附带 Android Gradle 工程或已签名 APK（生成这些需要本地 Android 工具链）。在项目目录执行：

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio 中选择 Build > Build APK(s)，或在 Android 工程目录执行 `./gradlew assembleDebug`。发布商店前请设置正式应用图标、签名密钥、隐私政策、网络安全策略与版本号。`webDir` 当前指向项目目录，生产构建建议将 Web 资源放入独立 `dist/` 目录并更新 Capacitor 配置，避免将开发文档打入应用。

## 五、数据与安全边界
- 本地资料和收藏/学习记录保存在浏览器 localStorage；清理浏览器数据会丢失。大规模法规正文、多人同步、权限控制建议迁移到后端数据库。
- 当前云端实现为前端 REST 只读连接，无登录/写入/同步冲突解决机制。不要把用户资料或敏感信息放入公开法规表。
- 法律文本准确性、时效性必须由官方来源和人工流程保证。应用不构成法律意见。
- AI 法律问答、权威题库、自动法规增量同步、版本差异、账户体系、云同步、全文搜索服务、审计日志尚未实现。

## 六、建议验收
1. 在“资料管理”录入一份资料，检索并查看全文。
2. 导出 JSON，再清空后导入，核对标题/正文/日期/状态。
3. 导出 CSV 后重新导入。
4. 检查筛选组合、收藏、复习卡和测验统计。
5. 按 schema 配置 Supabase 并测试只读访问；尝试通过客户端写入应被拒绝。
6. 用 Android Studio 构建 APK，并在真机测试安装、离线启动、文件导入和导出。
